<html lang="en">
<head>
    <title>
        Profile Page
    </title>
    <link rel="stylesheet" href="{{asset('css/style.css')}}">
</head>
<body>
<div class="all2">
    <div class="header">
        PROFILE
    </div>
<h3>This is your profile.</h3>
    <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
    <button class="btn" onclick="location.href = 'http://127.0.0.1:8000';">Home Page</button>
</div></body>
</html>
