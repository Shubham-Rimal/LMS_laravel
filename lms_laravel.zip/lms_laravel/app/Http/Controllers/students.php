<?php

namespace App\Http\Controllers;

class students
{

    public function __construct()
    {
    }
}
