<?php

namespace App\Http\Controllers;

use App\Models\Student;
use Illuminate\Http\Request;
use Intervention\Image\Facades\Image;

class PagesController extends Controller
{
    public function home() {
        $data=[
            'name'=>'Shubham',
            'age'=> 18
        ];
        return view('welcome')->with($data);
    }

    public function profile(){
        return view('profile');
    }

    public function create(){
        return view('create');
    }

    public function store(Request $request){
        $student = new Student();
        $student->name = $request->name;
        $student->address = $request->address;
        $student->age = $request->age;
        $img=Image::make($request->file('image'));
        $filenameWithExt=$request->file('image')->getClientOriginalName();
        $img->save('storage/image/'.$filenameWithExt);
        $student->image=$filenameWithExt;
        return redirect('/list');

    }

    public function list(){
        $students = Student::get();
        return view('list')->with('students',$students);
    }

    public function edit($id){
        $student = Student::where('id',$id)->first();
        return view('update')->with('student',$student);
    }

    public function update(Request $request){
        $student=Student::where('id',$request->id)->first();
        $student->name=$request->name;
        $student->address=$request->address;
        $student->age=$request->age;
        $student->image=$request->image;
        $student->save();
        return redirect('/list');
    }
}
