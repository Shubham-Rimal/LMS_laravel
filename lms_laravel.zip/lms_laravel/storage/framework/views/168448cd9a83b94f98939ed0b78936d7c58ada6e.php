<html lang="en">
<head>
    <title>List</title>
</head>
<body>
<a href="<?php echo e(url('/create')); ?>"><button>Create</button></a>
<table>
    <tr>
        <th>Name</th>
        <th>Address</th>
        <th>Age</th>
        <th>Image</th>
    </tr>
    <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($student->name); ?></td>
            <td><?php echo e($student->address); ?></td>
            <td><?php echo e($student->age); ?></td>
            <td><img src="<?php echo e(asset('storage/image/'.$student->image)); ?>"></td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\lms_laravel\resources\views/list.blade.php ENDPATH**/ ?>