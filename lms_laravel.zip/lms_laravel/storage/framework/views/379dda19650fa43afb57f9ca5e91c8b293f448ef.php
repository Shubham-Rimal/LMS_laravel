<html lang="en">
<head>
    <title>Welcome Page</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
</head>
<body>
<div class="all">
<div class="header">
    <p>WELCOME!</p>
</div>
    <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
    <button class="btn" onclick="location.href= 'http://127.0.0.1:8000/profile';">Visit Profile</button>
</div>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\lms_laravel\resources\views/welcome.blade.php ENDPATH**/ ?>